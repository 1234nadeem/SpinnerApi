package com.example.spinnerapidata.response;

import com.google.gson.annotations.SerializedName;

public class ObjARRegularizationTypeItem{

	@SerializedName("Text")
	private String text;

	@SerializedName("ID")
	private String iD;

	public String getText(){
		return text;
	}

	public String getID(){
		return iD;
	}
}