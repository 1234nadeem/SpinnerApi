package com.example.spinnerapidata.response;

public class RequestClass {

String UserId;
String TokenNo;

    public RequestClass(String userId, String tokenNo) {
        UserId = userId;
        TokenNo = tokenNo;
    }
}
