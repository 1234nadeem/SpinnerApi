package com.example.spinnerapidata;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.spinnerapidata.response.RequestClass;
import com.example.spinnerapidata.response.ResponseModel;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener  {
    Spinner spAgencies;
    EditText etName;
    ArrayList<String> agencyName = new ArrayList<>();
    public static ApiInterface apiService;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spAgencies = findViewById(R.id.spAgencies);
        spAgencies.setOnItemSelectedListener(this);
        etName=findViewById(R.id.etName);
        calling();
    }

    public void calling() {


          /*  HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor();
            httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BASIC);
            OkHttpClient.Builder builder = new OkHttpClient.Builder();
            builder.addInterceptor(httpLoggingInterceptor);
            builder.readTimeout(60, TimeUnit.SECONDS);
            builder.connectTimeout(60, TimeUnit.SECONDS);
            Gson gson = new GsonBuilder().setLenient().create();*/


        Retrofit retrofit = new Retrofit.Builder().baseUrl("https://saness.sansera.in/MobileAPI/AppServices.svc/").addConverterFactory(GsonConverterFactory.create()).build();

          ApiInterface  apiService = retrofit.create(ApiInterface.class);


            Call<ResponseModel> call = apiService.sendReq(new RequestClass("1890","abcHkl7900@8Uyhkj"));
            call.enqueue(new  Callback<ResponseModel>() {
                @Override
                public void onResponse(Call<ResponseModel> call, Response<ResponseModel> response) {

                  /*  if (response.body() != null) {
                        JsonObject jsonObject = response.body();
                        JSONObject jsonResponse = null;
                        Gson gson = new Gson();
                        Log.e("getTestResult", jsonObject.toString());
                        try {
                            jsonResponse = new JSONObject(jsonObject.toString());
                            Log.e("getTestResult", jsonResponse.toString());

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }*/
                    if (response.body().getMobileNo().equals("7259125430")) {
                        Log.d("testing",(response.body()).toString());
                        int length = response.body().objARRegularizationType.size();
                        for (int i = 1; i <= length; i++) {
                            agencyName.add(response.body().objARRegularizationType.get(i-1).getText());
                        }
                        setEditextData(response.body().getRMName());
                        ArrayAdapter adapter = new ArrayAdapter(MainActivity.this, R.layout.spinner_dropdown_marks, agencyName);
                        adapter.setDropDownViewResource(R.layout.spinner_dropdown_layout);
                        spAgencies.setAdapter(adapter);
                       // spAgencies.setOnItemSelectedListener(spAgencies.getOnItemSelectedListener());
                        adapter.setNotifyOnChange(true);
                        Toast.makeText(MainActivity.this, response.code() + " Response", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<ResponseModel> call, Throwable t) {

                }
            });

    }

    private void setEditextData(String rmName) {
       String temp="";
        char ch;
        for (int i=0; i<rmName.length(); i++)
        {
            ch= rmName.charAt(i); //extracts each character
            temp= ch+rmName; //adds each character in front of the existing string
        }
        etName.setText(temp);
        Log.d("settext",temp);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(this,agencyName.get(position) , Toast.LENGTH_SHORT).show();
       Log.d("tesst",agencyName.get(position) );
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}