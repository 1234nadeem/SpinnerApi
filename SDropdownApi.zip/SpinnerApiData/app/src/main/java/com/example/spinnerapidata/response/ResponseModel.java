package com.example.spinnerapidata.response;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResponseModel {

	@SerializedName("MobileNo")
	private String mobileNo;

	@SerializedName("Status")
	private boolean status;

	@SerializedName("IsRMSet")
	private boolean isRMSet;

	@SerializedName("Message")
	private Object message;

	@SerializedName("objARRegularizationType")
	public List<ObjARRegularizationTypeItem> objARRegularizationType;

	@SerializedName("RMName")
	private String rMName;

	public String getMobileNo(){
		return mobileNo;
	}

	public boolean isStatus(){
		return status;
	}

	public boolean isIsRMSet(){
		return isRMSet;
	}

	public Object getMessage(){
		return message;
	}

	public List<ObjARRegularizationTypeItem> getObjARRegularizationType(){
		return objARRegularizationType;
	}

	public String getRMName(){
		return rMName;
	}
}